@component('mail::message')
    <p style="text-align: center">
        otp <b>{{$random_number}}</b> of stock count  is generated on date.
        do not share this OTP with anyone
        This is your OPT code </p>
@endcomponent
