<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center mb-5">
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-6">
                    <div class="card">
                        <div class="card-body">
                            <p><b>Company Name: </b> <span> <?php echo e($item->company_name); ?> </span></p>
                            <p><b>Shareholder Count: </b> <span> <?php echo e($item->Shareholder_Count); ?> </span></p>
                            <p><b>Verified Members: </b> <span> <?php echo e($item->verified_count); ?> </span></p>
                            <p><b>Total Shares: </b> <span> <?php echo e($item->Total_Share); ?> </span></p>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card">
                    <div class="card-header text-center"><?php echo e(__('Register Your Account')); ?></div>

                    <div class="card-body">

                        <form method="POST" enctype="multipart/form-data" id="register_form"
                              action="javascript:void(0)">
                            <?php echo csrf_field(); ?>
                            <div id="error_message"></div>

                            <div class="form-group row" id="div_phone_number">
                                <label for="email"
                                       class="col-md-4 col-form-label text-md-right"><?php echo e(__('Phone Number')); ?></label>
                                <div class="col-md-6">
                                    <div class="input-group mb-3">
                                        <input id="phone_no" type="text"
                                               class="form-control <?php $__errorArgs = ['phone_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                               name="phone_no"
                                               value="<?php echo e(old('phone_no')); ?>" autocomplete="phone_no" autofocus>

                                        <div class="input-group-append">
                                            <button type="button" id="phone_number_send_verify_code"
                                                    class="btn btn-primary input-group-text">Verify Phone
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group row div-hidden" id="div_phone_number_verification">
                                <label for="verify_phone_number_code" class="col-md-4 col-form-label text-md-right"><?php echo e(__('SMS Verification Code')); ?></label>
                                <div class="col-md-6">
                                    <input id="verify_phone_number_code" type="text"
                                           class="form-control <?php $__errorArgs = ['verify_phone_number_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           name="verify_phone_number_code"
                                           value="<?php echo e(old('verify_phone_number_code')); ?>"
                                           autocomplete="verify_phone_number_code">

                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="first_name"
                                       class="col-md-4 col-form-label text-md-right"><?php echo e(__('First Name')); ?></label>

                                <div class="col-md-6">
                                    <input id="first_name" type="text"
                                           class="form-control <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           name="first_name" value="<?php echo e(old('first_name')); ?>"
                                           autocomplete="first_name">

                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="last_name"
                                       class="col-md-4 col-form-label text-md-right"><?php echo e(__('Last Name')); ?></label>

                                <div class="col-md-6">
                                    <input id="last_name" type="text"
                                           class="form-control <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           name="last_name" value="<?php echo e(old('last_name')); ?>"
                                           autocomplete="last_name">

                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="email"
                                       class="col-md-4 col-form-label text-md-right"><?php echo e(__('E-Mail Address')); ?></label>
                                <div class="col-md-6">
                                    <div class="input-group mb-3">
                                        <input id="email" type="email"
                                               class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email"
                                               value="<?php echo e(old('email')); ?>" autocomplete="email">
                                        <div class="input-group-append">
                                            <button type="button" id="email_send_verify_code" class="btn btn-primary input-group-text">Verify Email
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group row " id="div_email_verification">
                                <label for="verify_email_code"
                                       class="col-md-4 col-form-label text-md-right"><?php echo e(__('Email Verification Code')); ?></label>
                                <div class="col-md-6">
                                    <input id="verify_email_code" type="text"
                                           class="form-control <?php $__errorArgs = ['verify_email_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           name="verify_email_code" value="<?php echo e(old('verify_email_code')); ?>"
                                           autocomplete="verify_email_code">

                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="no_shares_own"
                                       class="col-md-4 col-form-label text-md-right"><?php echo e(__('No of Own Share')); ?></label>

                                <div class="col-md-6">
                                    <input id="no_shares_own" type="number"
                                           class="form-control <?php $__errorArgs = ['no_shares_own'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           name="no_shares_own" value="<?php echo e(old('no_shares_own')); ?>">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="date_purchase"
                                       class="col-md-4 col-form-label text-md-right"><?php echo e(__('Purchase Date')); ?></label>

                                <div class="col-md-6">
                                    <input id="date_purchase" type="date"
                                           class="form-control <?php $__errorArgs = ['date_purchase'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           name="date_purchase" value="<?php echo e(old('date_purchase')); ?>">

                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="brokage_name"
                                       class="col-md-4 col-form-label text-md-right"><?php echo e(__('Brokage Name')); ?></label>

                                <div class="col-md-6">
                                    <input id="brokage_name" type="text"
                                           class="form-control <?php $__errorArgs = ['brokage_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           name="brokage_name" value="<?php echo e(old('brokage_name')); ?>">

                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="company_id"
                                       class="col-md-4 col-form-label text-md-right"><?php echo e(__('Select Stock')); ?></label>

                                <div class="col-md-6">
                                    <select class="form-control" id="company_id" name="company_id">
                                        <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($company->id); ?>"><?php echo e($company->company_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="country_list"
                                       class="col-md-4 col-form-label text-md-right"><?php echo e(__('Select Country')); ?></label>

                                <div class="col-md-6">
                                    <select class="form-control" id="country_list" name="country_list">
                                        <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($country->name); ?>"><?php echo e($country->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="image"
                                       class="col-md-4 col-form-label text-md-right"><?php echo e(__('Image of Your Brokage App ')); ?></label>

                                <div class="col-md-6">
                                    <input id="image" type="file"
                                           class="form-control <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           name="image" value="<?php echo e(old('image')); ?>">
                                    <input id="image_base_64" type="hidden">
                                </div>
                            </div>
                            <div class="form-group row mb-0">
                                <div class="col-md-6 offset-md-6">
                                    <button type="submit" class="btn btn-primary">
                                        <?php echo e(__('Register')); ?>

                                    </button>
                                </div>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
    <script>
        $(document).ready(function (e) {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            /* Register User AJAX Call */
            $('#register_form').submit(function (e) {
                e.preventDefault();
                var formData = {
                    first_name: $("#first_name").val(),
                    last_name: $("#last_name").val(),
                    email: $("#email").val(),
                    verify_email_code: $("#verify_email_code").val(),
                    phone_no: $("#phone_no").val(),
                    verify_phone_number_code: $("#verify_phone_number_code").val(),
                    no_shares_own: $("#no_shares_own").val(),
                    brokage_name: $("#brokage_name").val(),
                    company_id: $("#company_id").val(),
                    country_list: $("#country_list").val(),
                    image: $("#image_base_64").val(),
                    date_purchase: $('#date_purchase').val(),
                    "_token": "<?php echo e(csrf_token()); ?>",
                };

                var type = "POST";
                $.ajax({
                    type: type,
                    url: "<?php echo e(route('register_post')); ?>",
                    method: "POST",
                    data: formData,
                    dataType: 'json',
                    success: function (data) {
                        var successMessage = '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert">&times;</button>User Created<div>';
                        $("#error_message").empty();
                        $("#error_message").append(successMessage);
                        setTimeout(() => {
                            window.location.href = window.location.href
                        }, 3000)
                    },
                    error: function (reject) {
                        if (reject.status === 400) {
                            var response = JSON.parse(reject.responseText);
                            var errorString = '<div class="alert alert-danger alert-dismissible"><button type="button" class="close" data-dismiss="alert">&times;</button><ul>';
                            $.each(response.errors, function (key, value) {
                                errorString += '<li>' + value[0] + '</li>';
                            });
                            errorString += '</ul><div>';
                            $("#error_message").append(errorString);
                        }
                    },

                });
            });

            /* Phone No Send Verification Code AJAX Call */


            /* Phone No Send Verification Code AJAX Call */
            $("#phone_number_send_verify_code").click(function (e) {
                e.preventDefault();
                var formData = {
                    phone_no: $('#phone_no').val(),
                    "_token": "<?php echo e(csrf_token()); ?>",
                };
                var type = "POST";
                $.ajax({
                    type: type,
                    url: "<?php echo e(route('phone_number_verification_code')); ?>",
                    data: formData,
                    dataType: 'json',
                    success: function (data) {
                        if (data.message == "user") {
                            $("#div_phone_number_verification").hide();

                            $("#email").val(data.user.email);
                            $("#first_name").val(data.user.first_name);
                            $("#last_name").val(data.user.last_name);

                            $("#email").prop("readonly",true);
                            $("#first_name").prop("readonly",true);
                            $("#last_name").prop("readonly",true);


                            if (data.user.phone_no_verify == 0) {
                                $("#div_phone_number_verification").removeClass('div-hidden');
                                var errorString = '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert">&times;</button>Please write OTP code <div>';
                                $("#error_message").empty();
                                $("#error_message").append(errorString);
                            }
                            else {
                                $("#phone_number_send_verify_code").addClass('div-hidden');
                            }
                        } else if (data.message == "code") {
                            $("#div_phone_number_verification").removeClass('div-hidden');
                            var errorString = '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert">&times;</button>Please write OTP code <div>';
                            $("#error_message").empty();
                            $("#error_message").append(errorString);
                        }
                    },
                    error: function (reject) {
                        // var errorString = '<div class="alert alert-danger alert-dismissible"><button type="button" class="close" data-dismiss="alert">&times;</button>Phone no format is invalid <div>';
                        // $("#error_message").empty();
                        // $("#error_message").append(errorString);
                    }
                });
            });

            /* Email Send Verification Code AJAX Call */

            /* Phone No Send Verification Code AJAX Call */
            $("#email_send_verify_code").click(function (e) {
                e.preventDefault();
                var formData = {
                    email: $('#email').val(),
                    "_token": "<?php echo e(csrf_token()); ?>",
                };
                var type = "POST";
                $.ajax({
                    type: type,
                    url: "<?php echo e(route('email_verification_code')); ?>",
                    data: formData,
                    dataType: 'json',
                    success: function (data) {

                    },
                });
            });

            /* Phone No On Change AJAX Call */
            $('#phone_no').change(function () {
                var formData = {
                    phone_no: $('#phone_no').val(),
                    "_token": "<?php echo e(csrf_token()); ?>",
                };
                var type = "POST";
                $.ajax({
                    type: type,
                    url: "<?php echo e(route('check_phone_number')); ?>",
                    data: formData,
                    dataType: 'json',
                    success: function (data) {
                        if (data.message == "user_exists") {
                            $("#div_phone_number_verification").hide();
                            $("#email").val(data.user.email);
                            $("#first_name").val(data.user.first_name);
                            $("#last_name").val(data.user.last_name);

                            $("#email").prop("readonly",true);
                            $("#first_name").prop("readonly",true);
                            $("#last_name").prop("readonly",true);

                            
                            if (data.user.phone_no_verify == "0") {
                                $("#div_phone_number_verification").removeClass('div-hidden');
                                $("#div_phone_number_verification").css('display', '');
                                var errorString = '<div class="alert alert-success alert-dismissible"><button type="button" class="close" data-dismiss="alert">&times;</button>User found <div>';
                                $("#error_message").empty();
                                $("#error_message").append(errorString);
                            }
                            else {
                                $("#phone_number_send_verify_code").addClass('div-hidden');
                            }
                        }
                    }
                });
            });
        });


        function readFile() {
            if (this.files && this.files[0]) {
                var FR = new FileReader();
                FR.addEventListener("load", function (e) {
                    document.getElementById("image_base_64").value = e.target.result;
                });
                FR.readAsDataURL(this.files[0]);
            }
        }

        document.getElementById("image").addEventListener("change", readFile);

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\Share-Count\resources\views/account/register.blade.php ENDPATH**/ ?>