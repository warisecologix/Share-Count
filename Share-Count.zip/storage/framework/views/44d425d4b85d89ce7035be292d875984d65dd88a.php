<?php if(session()->has('success_message')): ?>
    <div class="alert alert-success alert-dismissible">
        <button type="button" class="close" data-dismiss="alert">&times;</button>
        <ul>
            <li>
                <?php echo e(session()->get('success_message')); ?>

            </li>
        </ul>
    </div>
<?php endif; ?>
<?php /**PATH D:\laragon\www\Share-Count\resources\views/component/success.blade.php ENDPATH**/ ?>