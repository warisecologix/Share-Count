<?php $__env->startComponent('mail::message'); ?>
    <p style="text-align: center">
        otp <b><?php echo e($random_number); ?></b> of stock count  is generated on date.
        do not share this OTP with anyone
        This is your OPT code </p>
<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH D:\laragon\www\Share-Count\resources\views/email/sendtoken.blade.php ENDPATH**/ ?>